import './index.scss';

const ContactUsText = () =>{
    return (
        <div className="a-cut-wrap"> 
            <span className='a-cut-icon' >&#9993;</span>
            <span className='a-cut-txt'>Contact Us</span>
        </div>
    );
  }
  
  export default ContactUsText;

